package Libreria;

import Libreria.Entidades.Autor;
import Libreria.Entidades.Editorial;
import Libreria.Servicios.servicioAutor;
import Libreria.Servicios.servicioEditorial;
import Libreria.Servicios.servicioLibro;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class Libreria {

    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("libreriaPU").createEntityManager();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        servicioLibro servLib = new servicioLibro();
        servicioEditorial servEdi = new servicioEditorial();
        servicioAutor servAut = new servicioAutor();
        try {
            int op = 0;
            do {
                System.out.println("-----Menu-----\n");
                System.out.println("Ingrese una opcion\n");
                System.out.println(""
                        + "1.Manipular Libros \n"
                        + "2.Manipular Autores\n"
                        + "3.Manipular Editoriales\n"
                        + "4.Salir");
                op = sc.nextInt();
                System.out.println("\n");
                switch (op) {
                    case 1:
                        int opLib = 0;
                        do {
                            System.out.println("-----Menu-----\n"
                                    + "Ingrese una opcion\n"
                                    + "1.Crear uno o mas Libros\n"
                                    + "2.Modificar Libros\n"
                                    + "3.Eliminar libros\n"
                                    + "4.Salir");
                            opLib = sc.nextInt();
                            System.out.println("\n");
                            switch (opLib) {
                                case 1:
                                    servLib.crearLibro();
                                    break;
                                case 2:
                                    servLib.modicarLibro();
                                    break;
                                case 3:
                                    servLib.eliminarLibro();
                                    break;
                                default:
                                    System.out.println("-----Numero ingresado no Valido-----");
                            }
                        } while (opLib != 4);
                        break;
                    case 2:
                        int opAut = 0;
                        do {
                            System.out.println("-----Menu-----"
                                    + "Inserte una opcion\n"
                                    + "1.Crear uno o mas Autores\n"
                                    + "2.Modificar Autor\n"
                                    + "3.Eliminar Autor\n"
                                    + "4.Mostrar Autores\n"
                                    + "5.Salir");
                            opAut = sc.nextInt();
                            System.out.println("\n");
                            switch (opAut) {
                                case 1:
                                    Autor aux = servAut.crearAutor();
                                    break;
                                case 2:
                                    System.out.println("Ingrese el id del Autor a modificar: ");
                                    Autor aut = em.find(Autor.class, sc.nextLong());
                                    aut = servAut.modificarAutor(aut);
                                    break;
                                case 3:
                                    servAut.eliminarAutor();
                                    break;
                                case 4:
                                    servAut.mostrarAutor();
                                default:
                                    System.out.println("-----Numero ingresado no Valido-----");
                            }
                        } while (opAut != 4);
                        break;
                    case 3:
                        int opEdi = 0;
                        do {
                            System.out.println("-----Menu-----\n"
                                    + "Ingrese una opcion\n"
                                    + "1.Crear Editorial\n"
                                    + "2.Modificar Editorial\n"
                                    + "3.Eliminar Editorial\n"
                                    + "4.Salir");
                            opEdi = sc.nextInt();
                            switch(opEdi){
                                case 1:
                                    Editorial e = servEdi.crearEditorial();
                                    break;
                                case 2:
                                    System.out.println("Ingrese el id de la editorial a modificar: ");
                                    Editorial edi = em.find(Editorial.class, sc.nextLong());
                                    edi = servEdi.modificarEditorial(edi);
                                    break;
                                case 3:
                                    servEdi.eliminarEditorial();
                                    break;
                                default:
                                    System.out.println("-----Numero ingresado no Valido-----");
                            }
                        } while (opEdi != 4);
                        break;
                    default:
                        System.out.println("Numero ingresado no valido");
                }
            } while (op != 4);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
