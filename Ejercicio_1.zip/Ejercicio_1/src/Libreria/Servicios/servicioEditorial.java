package Libreria.Servicios;

import Libreria.Entidades.Editorial;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class servicioEditorial {

    private final Scanner sc = new Scanner(System.in).useDelimiter("\n");
    private final EntityManager em = Persistence.createEntityManagerFactory("libreriaPU").createEntityManager();

    public Editorial crearEditorial() throws Exception {
        try {
            Editorial ed1 = new Editorial();
            System.out.println("Ingrese el nombre de la Editorial");
            ed1.setNombre(sc.next());
            ed1.setAlta(true);
            System.out.println("Ingrese el id: ");
            ed1.setId(sc.nextLong());
            em.getTransaction().begin();
            em.persist(ed1);
            em.getTransaction().commit();
            System.out.println("La eitorial creada es: ");
            Editorial edAux = (Editorial) em.find(Editorial.class, ed1.getId());
            System.out.println(edAux.toString());
            return ed1;
        } catch (Exception e) {
            throw e;
        }
    }

    public Editorial modificarEditorial(Editorial edi) throws Exception {
        try {
            System.out.println("Ingrese el nombre modificado: ");
            edi.setNombre(sc.next());
            em.getTransaction().begin();
            em.merge(edi);
            em.getTransaction().commit();
            Editorial ediAux = em.find(Editorial.class, edi.getNombre());
            System.out.println("\n"
                    + "Editorial modificada: \n"
                    + ediAux.toString() + "\n");
            return edi;
        } catch (Exception e) {
            throw e;
        }
    }

    public void eliminarEditorial() throws Exception {
        try {
            System.out.println("Ingrese el id de la editorial a Eliminar: ");
            long id = sc.nextLong();
            Editorial edi = em.find(Editorial.class, id);
            em.getTransaction().begin();
            em.remove(edi);
            em.getTransaction().commit();
        } catch (Exception e) {
            throw e;
        }
    }
}
